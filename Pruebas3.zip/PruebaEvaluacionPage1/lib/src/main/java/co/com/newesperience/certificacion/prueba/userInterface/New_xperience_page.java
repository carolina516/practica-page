package co.com.newesperience.certificacion.prueba.userInterface;


import org.openga.seleniun.support.FindALL;
import net.serenetybdd.core.annotations.findby.FindBY;
import net.serenetybdd.core.pages.WebelementFacade;
import net.thucydides.core.annotations.DefaultUrl;

// definicion de pagina web

@DefaultUrl("http://automationpractice.com/index.php")

public class New_xperience_page  extends PageObject

{
	
//Logo de la pagina New_xperience
@FindBY(xpath="/html/body/div/div[1]/header/div[3]/div/div/div[1]/a/img")

public WebWebElementFacade logo_NW;

@FindBY(xpath="//*[@id="block_top_menu"]/ul")

public WebWebElementFacade menu;

@FindBY(xpath="//*[@id="contact-link"]/a")
public WebWebElementFacade Contacto;

	
}


