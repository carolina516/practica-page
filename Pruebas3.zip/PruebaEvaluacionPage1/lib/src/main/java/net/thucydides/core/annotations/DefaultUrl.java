package net.thucydides.core.annotations;

public class DefaultUrl {

}
