package co.com.newesperience.certificacion.prueba.Utilidades;

public class WebElementFacade {

	public static final String click = null;

	public boolean isDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isvisible() {
		// TODO Auto-generated method stub
		return false;
	}

}
