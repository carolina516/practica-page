package net;

public @interface serenitybdd {

}
