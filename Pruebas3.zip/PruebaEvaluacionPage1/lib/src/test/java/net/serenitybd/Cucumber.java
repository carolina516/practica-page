package net.serenitybd;

public class Cucumber {

}
