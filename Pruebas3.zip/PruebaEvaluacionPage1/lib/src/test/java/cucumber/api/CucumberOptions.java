package cucumber.api;

public class CucumberOptions {

}
