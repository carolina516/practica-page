package cucumber.api.java.en;

public class Given {

}
