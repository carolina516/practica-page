package co.com.newesperience.certificacion.prueba.NEweb;

public @interface cucumberOptions {

	String[] Plugin();

	String features();

	String[] glue();

}
