package co.com.newesperience.certificacion.prueba.Utilidades;



public class Utilidades {
	
	//metodo para saber si es visibl eun elemento
	  
	  public boolean elemento_visible(WebElementFacade elemt)
	  {
	  
	  if( elemt.isDisplayed()&& elemt.isvisible())
	  {
	  return true;
	  }
	  
	  else
	  {
	  return false;
	  }
	  }
	  //metodo para dar click
	  
	  
	  public void dar_click(WebElementFacade elemt)
	  
	  {
	  if ( elemt.isDisplayed()&& elemt.isvisible())
	  {
	  elemt.click;
	  }
	  
	  }
}
	  
	  
	  


