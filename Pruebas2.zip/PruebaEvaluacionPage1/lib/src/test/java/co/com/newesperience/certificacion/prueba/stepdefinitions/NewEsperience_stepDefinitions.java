package co.com.newesperience.certificacion.prueba.stepdefinitions;

import cucumber.api.java.en.Given;



public class NewEsperience_stepDefinitions


{
	@Given("Iam positioned in the home of the page$")
	
	public void IampositionedInthehomeofthepage ()
	{
		
	}

}
