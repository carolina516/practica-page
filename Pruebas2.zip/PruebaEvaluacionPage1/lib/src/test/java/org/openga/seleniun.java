package org.openga;

public @interface seleniun {

	public @interface WebElement {

	}

}
