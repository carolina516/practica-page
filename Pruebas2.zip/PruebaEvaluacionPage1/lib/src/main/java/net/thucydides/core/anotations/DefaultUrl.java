package net.thucydides.core.anotations;

public class DefaultUrl {

}
