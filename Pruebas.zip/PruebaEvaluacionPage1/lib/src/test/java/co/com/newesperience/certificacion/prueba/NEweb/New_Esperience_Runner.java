package co.com.newesperience.certificacion.prueba.NEweb;

import org.junit.runner.RunWith;
import org.junit.runner.Runner;

import cucumber.api.cucucumber.CucumberWithSerenity;
@RunWith(CucumberWithSerenity.class)
@cucumberOptions
(
		
Plugin= {"pretty","html:target/cucumber","junit:target/cucumber.xml"},		
features="src/test/resources/FEATURES",
glue={"co.com.newesperience.certificacion.prueba.stepdefinitions;"},
snippets=Snippet Type.CAMELCASE

)



public class New_Esperience_Runner {
	
	

}
