package cucumber.api.cucucumber;

public @interface CucumberWithSerenity {

}
