package co.com.newesperience.certificacion.prueba.userInterface;

public @interface DefaultUrl {

	String value();

	String value();

	String value();

}
