package org.openga.seleniun.support;

public @interface FindALL {

}
