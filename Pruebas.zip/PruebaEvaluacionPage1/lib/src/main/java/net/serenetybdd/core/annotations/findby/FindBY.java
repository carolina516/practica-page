package net.serenetybdd.core.annotations.findby;

public @interface FindBY {

	String xpath();

	String xpath();

	String xpath();

}
