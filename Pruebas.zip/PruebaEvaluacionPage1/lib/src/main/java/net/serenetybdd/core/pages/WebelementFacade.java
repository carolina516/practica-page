package net.serenetybdd.core.pages;

public class WebelementFacade {

}
